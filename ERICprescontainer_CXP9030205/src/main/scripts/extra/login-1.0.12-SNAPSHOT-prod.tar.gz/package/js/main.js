// To get parameters in URI query part
function getParameterByName(query, name) {
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");

    var regexS = "[\\?&]" + name + "=([^&]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(query);

    if (results == null) {
        return "";
    } else {
        return decodeURIComponent(results[1].replace(/\+/g, " "));
    }
}

function updateQueryStringParameter(uri, key, value) {
    if (uri === null) {
        return null;
    }

    if (key === null) {
        return uri;
    }

    var re = new RegExp("([?|&])" + key + "=.*?(&|$)", "i");
    var separator = uri.indexOf('?') !== -1 ? "&" : "?";
    if (uri.match(re)) {
        return uri.replace(re, '$1' + key + "=" + value + '$2');
    } else {
        return uri + separator + key + "=" + value;
    }
}

// trim function, to remove spaces in string
function trim(string) {
    if (string === null) {
        return null;
    }

    return string.replace(/^\s+|\s+$/g, "");
}

var options = {
    "emptyMessage": "Please enter your username and password",
    "emptyNameMessage": "Please enter your username",
    "emptyPassMessage": "Please enter your password",
    "loginFailed": "Your username/password appears to be invalid. Please try again"
};

var FAILING_USER_FIELD = 'torLogin-Holder-loginUsername_error_true';
var FAILING_PASS_FIELD = 'torLogin-Holder-loginPassword_error_true';

// Form client side validation
function validate(name, password, messageBox) {
    var message = '';

    // remove error highlights from input fields

    name.removeClass(FAILING_USER_FIELD);
    password.removeClass(FAILING_PASS_FIELD);

    if (trim(password.val()) === '' && trim(name.val()) === '') {
        message = options['emptyMessage'];

        name.addClass(FAILING_USER_FIELD);
        password.addClass(FAILING_PASS_FIELD);
    } else if (trim(name.val()) === '') {
        //Check if name is empty, if empty, then highlight
        message = options['emptyNameMessage'];

        name.addClass(FAILING_USER_FIELD);
    } else if (trim(password.val()) === '') {
        // Check if password is empty, if empty then highlight
        message = options['emptyPassMessage'];

        password.addClass(FAILING_PASS_FIELD);
    }

    // If some of fields is empty, then show error message
    messageBox.html(message);

    return message === '';
}

function getQueryParams() {
    return window.location.search;
}

function getCurrentUrl() {
    return window.location.href;
}

function getHash() {
    return window.location.hash;
}

function getFailUrl(currentUrl) {
    // If we happen to receive empty url, it is the url of current site
    if (currentUrl === null || currentUrl === undefined || currentUrl.replace(' ', '') === '') {
        currentUrl = getCurrentUrl();
    }

    // Add it to dummy anchor element;
    var a = document.createElement('a');
    a.href = currentUrl;

    var goto = getParameterByName(a.search, 'goto');

    // Add hash part to goto parameter as it is part of goto parameter, just not escaped if using bookmarked url
    if (a.hash !== '' && a.hash !== '#') {
        goto += a.hash;

        // Remove the hash part from dummy anchor so that it is not part of failUrl, but goto parameter
        a.hash = null;
    }

    var failUrl = a.href;
    if (goto && goto !== '') {
        // Encode goto parameter
        goto = encodeURIComponent(goto);

        // Add goto parameter to the url
        failUrl = updateQueryStringParameter(failUrl, 'goto', goto);
    }

    // Add login parameter to flag that it is false
    failUrl = updateQueryStringParameter(failUrl, 'login', STATUS_FAIL);

    return failUrl;
}

var STATUS_FAIL = 'fail';
var form;

$(function () {
    // DOM has loaded, so assign value to form;
    form = $('#loginForm');

    var name = form.find('#loginUsername'),
        password = form.find('#loginPassword'),
        messageBox = form.find('#messagesBox');

    // Add goto hidden field if goto url parameter has been passed in
    var gotoUrl = getParameterByName(getQueryParams(), 'goto');
    if (gotoUrl) {
        // Decode gotoUrl in case it was encoded before
        gotoUrl = decodeURIComponent(gotoUrl);

        // If url accessed was not escaped, then we have to add hash manually to it
        var hash = getHash();

        if (hash != '') {
            gotoUrl += hash;
        }

        // For SSO no need to encode it anymore as it is treated just as a string on serverside
        // gotoUrl = encodeURIComponent(gotoUrl);

        form.append(
            $('<input/>', {
                type: 'hidden',
                name: 'goto',
                value: gotoUrl
            })
        );
    }

    // Create url that will be executed if login has failed
    var failUrl = getFailUrl(decodeURI(window.location.href));

    form.append(
        $('<input/>', {
            type: 'hidden',
            name: 'gotoOnFail',
            value: failUrl
        })
    );

    // Show error message, if login has failed
    var login = getParameterByName(getQueryParams(), 'login');
    if (login && login === STATUS_FAIL) {
        messageBox.text(options.loginFailed);

        name.addClass(FAILING_USER_FIELD);
        password.addClass(FAILING_PASS_FIELD);
    }

    // Validate the form
    form.submit(function () {
        return validate(name, password, messageBox);
    });
});